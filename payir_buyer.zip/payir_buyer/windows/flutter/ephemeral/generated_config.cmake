# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\develop\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\Hariharan\\Downloads\\payir_buyer\\payir_buyer" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\develop\\flutter"
  "PROJECT_DIR=C:\\Users\\Hariharan\\Downloads\\payir_buyer\\payir_buyer"
  "FLUTTER_ROOT=C:\\develop\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\Hariharan\\Downloads\\payir_buyer\\payir_buyer\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\Hariharan\\Downloads\\payir_buyer\\payir_buyer"
  "FLUTTER_TARGET=C:\\Users\\Hariharan\\Downloads\\payir_buyer\\payir_buyer\\lib\\main.dart"
  "DART_DEFINES=Zmx1dHRlci5pbnNwZWN0b3Iuc3RydWN0dXJlZEVycm9ycz10cnVl,RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNTAuMA==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049YWIyOTEyMDM1ZQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049MzcxZjc3MjAyYQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xNC4w"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\Hariharan\\Downloads\\payir_buyer\\payir_buyer\\.dart_tool\\package_config.json"
)
